<?php
$con=mysqli_connect("localhost", "root", "", "camsdb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
